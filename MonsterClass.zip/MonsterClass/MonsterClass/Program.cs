﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterClass
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayOpeningScreen();
            DisplayMenu();
            DisplayClosingScreen();
        }

        static SeaMonster IntializeSeaMonster()
        {
            return new SeaMonster
            {
                GetId = 5,
                GetName = "Nessie",
                GetAge = 34,
                HasGills = true,
                HomeSea = "Loch Ness"
                
            };
        }

        static SpaceMonster IntializeSpaceMonster()
        {
            return new SpaceMonster
            {
                GetId = 51,
                GetName = "Grey",
                GetAge = 230,
                Galaxy = "Milky Way"
            };
        
        }

         static void DisplayMenu()
        {
            bool exitMenu = false;
            int menuSelection;
            SeaMonster MySeaMonster;
            SpaceMonster MySpaceMonster;
            LandMonster MyLandMonster;

            MySeaMonster = IntializeSeaMonster();
            MySpaceMonster = IntializeSpaceMonster();
            MyLandMonster = IntializeLandMonster();

            do
            {
                Console.Clear();
                Console.WriteLine("MENU");
                Console.WriteLine("1) Display Monsters");
                Console.WriteLine("2) Exit");
                Console.WriteLine("3) Edit Sea Monster");
                Console.Write("Enter Selection: ");
                menuSelection = int.Parse(Console.ReadLine());

                switch (menuSelection)
                {
                    case 1:
                        DisplayMonsterInfoScreen(MySeaMonster, MySpaceMonster, MyLandMonster);
                        break;
                    case 2:
                        exitMenu = true;
                        break;
                    case 3:
                        DisplayEditSeaMonster(MySeaMonster);
                        break;
                    default:
                        Console.WriteLine("Please enter a proper number");
                        DisplayContinuePrompt();
                        break;
                }
            } while (!exitMenu);
        }

        private static LandMonster IntializeLandMonster()
        {
            {
                return new LandMonster
                {
                    GetId = 202,
                    GetName = "Sasquatch",
                    GetAge = 45,
                    Habitat = "Forest"
                };

            }

        }

        private static void DisplayEditSeaMonster(SeaMonster mySeaMonster)
        {
            Console.Write("Enter name of new seamonster:");
            mySeaMonster.GetName = Console.ReadLine();
            Console.Write("Enter home sea of new seamonster:");
            mySeaMonster.HomeSea = Console.ReadLine();
            Console.Write("Enter Age");
            int.TryParse(Console.ReadLine(), out int age);
            mySeaMonster.GetAge = age;
            Console.Write("has Gills?");
            if (Console.ReadLine().ToUpper() == "YES")
            {
                mySeaMonster.HasGills = true;
            }
            else
            {
                mySeaMonster.HasGills = false;
            }
            

            DisplayContinuePrompt();
        }

        static void DisplayMonsterInfoScreen(SeaMonster seaMonster, SpaceMonster spaceMonster, LandMonster landMonster)
        {
            Console.WriteLine("Monster Info");

            Console.WriteLine("Sea Monsters:");
            DisplaySeaMonsters(seaMonster);
            Console.WriteLine();

            Console.WriteLine("Space Monsters:");
            DisplaySpaceMonsters(spaceMonster);
            Console.WriteLine();

            Console.WriteLine("Land Monsters:");
            DisplaylandMonsters(landMonster);
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        private static void DisplaylandMonsters(LandMonster landMonster)
        {
            Console.WriteLine($"Id: {landMonster.GetId}");
            Console.WriteLine($"Name: {landMonster.GetName}");
            Console.WriteLine($"Age: {landMonster.GetAge}");
            Console.WriteLine($"Habitat: {landMonster.Habitat}");
            Console.WriteLine($"Is Happy: {landMonster.IsHappy()}");

            Console.WriteLine($"You attacked {landMonster.GetName} and they {landMonster.MonsterBattleResponse()}");
        }

        private static void DisplaySeaMonsters(SeaMonster seaMonster)
        {
            Console.WriteLine($"Id: {seaMonster.GetId}");
            Console.WriteLine($"Name: {seaMonster.GetName}");
            Console.WriteLine($"Age: {seaMonster.GetAge}");
            Console.WriteLine($"Home Sea: {seaMonster.HomeSea}");
            Console.WriteLine($"Has Gills: {seaMonster.HasGills}");
            Console.WriteLine($"Is Happy: {seaMonster.IsHappy()}");

            Console.WriteLine($"You attacked {seaMonster.GetName} and they {seaMonster.MonsterBattleResponse()}");
        }
        private static void DisplaySpaceMonsters(SpaceMonster spaceMonster)
        {
            Console.WriteLine($"Id: {spaceMonster.GetId}");
            Console.WriteLine($"Name: {spaceMonster.GetName}");
            Console.WriteLine($"Age: {spaceMonster.GetAge}");
            Console.WriteLine($"Galaxy: {spaceMonster.Galaxy}");
            Console.WriteLine($"Is Happy: {spaceMonster.IsHappy()}");

            Console.WriteLine($"You attacked {spaceMonster.GetName} and they {spaceMonster.MonsterBattleResponse()}");
        }

        static void DisplayOpeningScreen()

        {


            Console.Clear();



            Console.WriteLine();

            Console.WriteLine("\t\tMonsters");

            Console.WriteLine();
            DisplayContinuePrompt();



        }

        static void DisplayContinuePrompt()

        {

            Console.WriteLine();

            Console.WriteLine("Press any key to continue.");

            Console.ReadKey();

        }
        static void DisplayClosingScreen()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to Exit");
            Console.ReadKey();
        }


    }
}
