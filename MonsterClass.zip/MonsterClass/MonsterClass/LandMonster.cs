﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterClass
{
    class LandMonster : Monster, IBattle
    {
        private string _habitat;

        public string Habitat
        {
            get { return _habitat; }
            set { _habitat = value; }
        }

        public override string Greeting()
        {
            return $"Hello, my name is {base.GetName} and I live in a {_habitat} habitat.";
        }

        public override bool IsHappy()
        {
            return true;
        }

        public MonsterAction MonsterBattleResponse()
        {
            Random randomNumber = new Random();
            int battleResponseNumber = randomNumber.Next(0, 101);
            if (battleResponseNumber >= 66)
            {
                return MonsterAction.Attack;
            }
            else if (battleResponseNumber >= 33)
            {
                return MonsterAction.Defend;
            }
            else
            {
                return MonsterAction.Retreat;
            }


        }


    }
}
