﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterClass
{
    public abstract class Monster
    {
        public enum MonsterAction
        { Attack, Defend, Retreat
        }

        private string _Name;
        private int _Age;
        private string _Height;
        private string _Weight;



        public int GetId { get; set; }
        public string GetName
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }
        public int GetAge
        {
            get
            {
                return _Age;
            }
            set
            {
                _Age = value;
            }
        }
        public string GetHeight
        {
            get
            {
                return _Height;
            }
            set
            {
                _Height = value;
            }
        }
        public string GetWeight
        {
            get
            {
                return _Weight;
            }
            set
            {
                _Weight = value;
            }
        }


        


        public virtual string Greeting()
        {
            return $"Hello, my name is {_Name}";
        }

        public abstract bool IsHappy();


        
    }


}
